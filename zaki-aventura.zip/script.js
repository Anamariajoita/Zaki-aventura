
function startGame() {
  document.getElementById('start-screen').style.display = 'none';
  document.getElementById('gameCanvas').style.display = 'block';
  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");

  let zakiX = 50;
  let zakiY = 300;
  let zakiVelY = 0;
  let isJumping = false;

  const zakiImg = new Image();
  zakiImg.src = 'assets/zaki.png';

  window.addEventListener("keydown", (e) => {
    if (e.code === "Space" && !isJumping) {
      zakiVelY = -10;
      isJumping = true;
    }
  });

  function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // gravitație
    zakiVelY += 0.5;
    zakiY += zakiVelY;

    if (zakiY > 300) {
      zakiY = 300;
      zakiVelY = 0;
      isJumping = false;
    }

    ctx.drawImage(zakiImg, zakiX, zakiY, 50, 50);
    requestAnimationFrame(gameLoop);
  }

  gameLoop();
}
